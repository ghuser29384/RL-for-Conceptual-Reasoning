import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const DEFAULT_STAGING_API_ORIGIN = "https://jnpoxvalyjtdghnperyu.supabase.co/functions/v1/metaphilosophy-staging";
const SECURITY_HEADERS = Object.freeze({
  "Cache-Control": "no-store",
  "Referrer-Policy": "no-referrer",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
});
const MIME = Object.freeze({
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".txt": "text/plain; charset=utf-8",
});
const STAGING_ROUTES = new Set([
  "/access", "/me", "/logout", "/assignment", "/draft", "/submit", "/receipt", "/correction", "/correction-submit", "/withdrawal", "/rerating", "/signoff",
  "/operator/state", "/operator/replace-invite", "/operator/revoke-user", "/operator/expire-session", "/operator/resolve-correction", "/operator/resolve-withdrawal", "/operator/open-cases", "/operator/request-rerating", "/operator/backup", "/operator/purge-drafts", "/operator/restore-drafts", "/operator/verify-backup-restore", "/operator/durable-readback", "/operator/incident", "/operator/complete-run",
  "/adjudicator/cases", "/adjudicator/resolve",
]);

export function createLmcaServer({
  rootDir = resolve("."),
  distDir = resolve(rootDir, "dist"),
  stagingApiOrigin = process.env.STAGING_API_ORIGIN ?? DEFAULT_STAGING_API_ORIGIN,
} = {}) {
  return createServer(async (request, response) => {
    try {
      const url = new URL(request.url ?? "/", "http://127.0.0.1");
      if (url.pathname === "/api/health") {
        return sendJson(response, 200, {
          status: "ok",
          authMode: "opaque_one_time_invites_and_revocable_sessions",
          stagingApiOrigin,
          syntheticOnly: true,
          outreachAuthorized: false,
        });
      }
      if (url.pathname === "/api/staging") {
        return proxyStaging(request, response, url, stagingApiOrigin);
      }
      return serveStatic(response, distDir, url.pathname);
    } catch (error) {
      console.error(error);
      return sendJson(response, 500, { error: "server_failed_closed", message: "Local staging server failed closed" });
    }
  });
}

async function proxyStaging(request, response, url, origin) {
  const route = url.searchParams.get("route") ?? "";
  if (!STAGING_ROUTES.has(route)) return sendJson(response, 404, { error: "route_not_found" });
  if (!["GET", "POST", "PUT"].includes(request.method ?? "")) {
    response.setHeader("Allow", "GET, POST, PUT");
    return sendJson(response, 405, { error: "method_not_allowed" });
  }
  const body = request.method === "GET" ? undefined : await readRequestBody(request, 1_000_000);
  const headers = {
    "Content-Type": "application/json",
    "X-Request-Id": request.headers["x-request-id"] ?? crypto.randomUUID(),
  };
  if (typeof request.headers.authorization === "string") headers.Authorization = request.headers.authorization;
  const upstream = await fetch(`${origin}${route}`, { method: request.method, headers, body, redirect: "error" });
  const text = await upstream.text();
  response.writeHead(upstream.status, {
    ...SECURITY_HEADERS,
    "Content-Type": upstream.headers.get("content-type") ?? "application/json; charset=utf-8",
    ...(upstream.headers.get("x-request-id") ? { "X-Request-Id": upstream.headers.get("x-request-id") } : {}),
  });
  response.end(text);
}

async function serveStatic(response, distDir, requestPath) {
  const routeMap = new Map([
    ["/", "/index.html"], ["/index.html", "/index.html"],
    ["/research", "/research/index.html"], ["/research/", "/research/index.html"],
    ["/arguments", "/arguments/index.html"], ["/arguments/", "/arguments/index.html"],
    ["/contribute", "/reviewers/closed.html"], ["/contribute/", "/reviewers/closed.html"],
    ["/reviewers", "/reviewers/closed.html"], ["/reviewers/", "/reviewers/closed.html"],
    ["/workspace", "/index.html"], ["/workspace/", "/index.html"],
    ["/reference", "/index.html"], ["/reference/", "/index.html"],
    ["/staging", "/staging/index.html"], ["/staging/", "/staging/index.html"],
  ]);
  const mapped = routeMap.get(requestPath) ?? requestPath;
  const candidate = resolve(distDir, `.${mapped}`);
  const normalizedRoot = resolve(distDir);
  if (candidate !== normalizedRoot && !candidate.startsWith(`${normalizedRoot}${sep}`)) return sendJson(response, 400, { error: "invalid_path" });
  let filePath = candidate;
  try {
    const info = await stat(filePath);
    if (info.isDirectory()) filePath = resolve(filePath, "index.html");
    const contents = await readFile(filePath);
    response.writeHead(200, {
      ...SECURITY_HEADERS,
      "Content-Type": MIME[extname(filePath)] ?? "application/octet-stream",
      ...(mapped.startsWith("/staging/") ? { "X-Robots-Tag": "noindex, nofollow, noarchive" } : {}),
    });
    response.end(contents);
  } catch {
    sendJson(response, 404, { error: "not_found" });
  }
}

async function readRequestBody(request, maxBytes) {
  const chunks = [];
  let total = 0;
  for await (const chunk of request) {
    total += chunk.length;
    if (total > maxBytes) throw new Error("request body too large");
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function sendJson(response, status, body) {
  response.writeHead(status, { ...SECURITY_HEADERS, "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(body));
}

const invokedPath = process.argv[1] ? resolve(process.argv[1]) : null;
if (invokedPath === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT ?? 4173);
  const server = createLmcaServer();
  server.listen(port, "127.0.0.1", () => {
    console.log(`Metaphilosophy local server listening on http://127.0.0.1:${port}`);
  });
}
